﻿using LigaWeb.Data.Entities;

namespace LigaWeb.Data.Repositories.Interfaces
{
    public interface IClubRepository : IGenericRepository<Club>
    {
    }
}
