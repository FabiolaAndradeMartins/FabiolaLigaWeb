﻿using LigaWeb.Data.Entities;

namespace LigaWeb.Data.Repositories.Interfaces
{
    public interface IGameRepository : IGenericRepository<Game>
    {
    }
}
